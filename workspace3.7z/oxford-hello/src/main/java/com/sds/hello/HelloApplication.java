package com.sds.hello;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.event.EventListener;

@SpringBootApplication(scanBasePackages = {"com.sds"})
public class HelloApplication extends SpringBootServletInitializer {

    private static final String SPRING_CONFIG_LOCATIONS = "spring.config.location=classpath:config/application.yml";

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return startYourEngines(builder);
    }

    public static void main(String[] args) {
        startYourEngines(new SpringApplicationBuilder()).run(args);
    }

    private static SpringApplicationBuilder startYourEngines(SpringApplicationBuilder builder) {
        System.out.println("---------------------------");
        System.out.println("-   Start Your Engines!   -");
        System.out.println("---------------------------");

        return builder
            .properties(SPRING_CONFIG_LOCATIONS)
            .sources(HelloApplication.class);
    }


    @EventListener(ApplicationReadyEvent.class)
    public void onApplicationReady(ApplicationReadyEvent event) {
        System.out.println("---------------------------");
        System.out.println("-    Application Ready    -");
        System.out.println("---------------------------");
    }
}
