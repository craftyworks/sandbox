#!/bin/bash

set -e

_program="$0"
while [ -h "$_program" ] ; do
  ls=$(ls -ld "$_program")
  link=$(expr "$ls" : '.*-> \(.*\)$')
  if expr "$link" : '/.*' > /dev/null; then
    _program="$link"
  else
    _program=$(dirname "$_program")/"$link"
  fi
done
_dir=$(dirname "$_program")

function readProperty {
  grep "${1}" "${2}" | cut -d '=' -f2-
}

#==================== copy nginx.conf ====================
NGINX_HOME=/data/web/nginx
# create paths for nginx configurations
mkdir -p "${NGINX_HOME}/conf/conf.d"
cat "${_dir}"/templates/nginx/nginx.conf > "${NGINX_HOME}/conf/nginx.conf"

#==================== create http server configuration ====================
function createWebServer {
  _properties="${1}"
  _web_server_name=$(readProperty 'web.server.name' "$_properties")
  _web_server_port=$(readProperty 'web.server.port' "$_properties")
  _web_server_root=$(readProperty 'web.server.root' "$_properties")
  _webapp_port=$(readProperty 'webapp.port' "$_properties")

  _server_conf_name="${NGINX_HOME}"/conf/conf.d/"${_web_server_name}".conf

  sed "s/WEB_SERVER_PORT/${_web_server_port}/g" "${_dir}"/templates/nginx/server.conf | \
  sed "s/WEB_SERVER_ROOT/${_web_server_root}/g" | \
  sed "s/WEBAPP_PORT/${_webapp_port}/g" \
  > "${_server_conf_name}"

  echo server configuration created for "${_web_server_name}"
  cat "${_server_conf_name}"

  _static_origin=$(readProperty 'web.server.static.origin' "$_properties")

  if [ -n "${_static_origin}" ]
  then
    TEMP_STAGING_DIR='/tmp/codedeploy-deployment-staging-area'
    _static_origin="${TEMP_STAGING_DIR}"/"${_static_origin}"
    _webapp_base=/data/web-app/"${_web_server_root}"

    mkdir -p "${_webapp_base}"
    cp -R "${_static_origin}"/** "${_webapp_base}"
    chown -R nginx:web "${_webapp_base}"

    echo Static resources are copied.
    ls -al "${_webapp_base}"
  fi
}
_server_conf=$(createWebServer "$_dir"/properties/nginx/web.properties)
echo "${_server_conf}"

chown -R nginx:web "${NGINX_HOME}/conf"

systemctl enable nginx
systemctl start nginx

#logrotate configuration overwrite (yes : overwrite)
#yes | cp -v "${_dir}"/templates/nginx/logrotate /etc/logrotate.d/nginx
