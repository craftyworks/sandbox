#!/bin/bash

_was_id="was1"
_properties="${_was_id}.properties"

set -e

_program="$0"
while [ -h "$_program" ] ; do
  ls=$(ls -ld "$_program")
  link=$(expr "$ls" : '.*-> \(.*\)$')
  if expr "$link" : '/.*' > /dev/null; then
    _program="$link"
  else
    _program=$(dirname "$_program")/"$link"
  fi
done
_dir=$(dirname "$_program")

_properties="$_dir"/properties/tomcat/"$_properties"
echo "--- Read properties from ${_properties}"
cat "${_properties}"
echo "-------------------------------------------"

function readProperty {
  grep "^${1}" "${_properties}" | cut -d '=' -f2-
}

_webapp_name=$(readProperty 'webapp.name')
_webapp_port=$(readProperty 'webapp.port')
_shutdown_port=$(readProperty 'webapp.shutdown_port')
_artifact_name=$(readProperty 'webapp.artifact_name')
_webapp_java_opts=$(readProperty 'webapp.java.opts' | sed "s/\//\\\\\//g")
_session_timeout=$(readProperty 'webapp.session.timeout')
_spring_profile=$(readProperty 'spring.profiles.active')
_heap_memory=$(readProperty 'jvm.heap.memory')
_tomcat_update_bin=$(readProperty 'tomcat.update.bin')
_tomcat_version=$(readProperty 'tomcat.version')
_valve_http_port=$(readProperty 'valve.http.port')

# exit when webapp.name is empty
if [ -z "${_webapp_name}" ]
then
    exit 0
fi

WEBAPP_NAME="${_webapp_name:-ROOT}"
WEBAPP_PORT="${_webapp_port:-9080}"
SHUTDOWN_PORT="${_shutdown_port:-9005}"
WEBAPP_JAVA_OPTS="${_webapp_java_opts}"
SPRING_PROFILE="${_spring_profile}"
TOMCAT_VERSION="${_tomcat_version:=tomcat9}"
VALVE_HTTP="${_valve_http_port:=80}"

CATALINA_HOME="/data/was/${TOMCAT_VERSION}"
CATALINA_BASE="${CATALINA_HOME}/${WEBAPP_NAME}"

APP_BASE="/data/was-app/${WEBAPP_NAME}"

echo "Install '${WEBAPP_NAME}' web application on port ${WEBAPP_PORT}. CATALINA_BASE=[${CATALINA_BASE}]"

# tomcat 8.0.1 install for auto scale out
if [ -d /data/was/tomcat8/bin ]; then
    echo "tomcat8 already exists"
else
    echo "tomcat8 installation start"
    unzip -o "${_dir}"/lib/apache-tomcat-8.0.1.zip -d "${CATALINA_HOME}"
    chown -R tomcat:was "${CATALINA_HOME}"
    chmod -R 775 "${CATALINA_HOME}"

    cp "${_dir}"/lib/*.jar "${CATALINA_HOME}"/lib/
    chown -R tomcat:was "${CATALINA_HOME}"/lib/
    chmod -R 775 "${CATALINA_HOME}"/lib/
fi

# create paths of web application
mkdir -p "${CATALINA_BASE}"
mkdir -p "${CATALINA_BASE}/logs"
mkdir -p "${CATALINA_BASE}/bin"

# create application file upload & logs paths
mkdir -p /data/File_Upload
mkdir -p /data/logs
chown -R tomcat:was /data/File_Upload
chown -R tomcat:was /data/logs
chmod 775 /data/File_Upload
chmod 775 /data/logs

cp -R ${CATALINA_HOME}/conf ${CATALINA_BASE}
echo "Paths for web application is created."

# copy custom context.xml & context.properties
cp "${_dir}"/templates/tomcat/context.xml "${CATALINA_BASE}"/conf/
cp "${_dir}"/templates/tomcat/context-redis.yaml "${CATALINA_BASE}"/conf/
cp "${_dir}"/templates/tomcat/context-${_was_id}.properties "${CATALINA_BASE}"/conf/context.properties

# add configuration properties replacement
_CATALINA_PROPERTIES="${CATALINA_BASE}"/conf/catalina.properties
_CONTEXT_PROPERTY_SOURCE="org.apache.tomcat.util.digester.PROPERTY_SOURCE=com.sds.tomcat.ContextPropertySource"
_REPLACE_SYSTEM_PROPERTIES="org.apache.tomcat.util.digester.REPLACE_SYSTEM_PROPERTIES=true"

grep -qxF "${_CONTEXT_PROPERTY_SOURCE}" "${_CATALINA_PROPERTIES}" || echo "${_CONTEXT_PROPERTY_SOURCE}" >> "${_CATALINA_PROPERTIES}"
grep -qxF "${_REPLACE_SYSTEM_PROPERTIES}" "${_CATALINA_PROPERTIES}" || echo "${_REPLACE_SYSTEM_PROPERTIES}" >> "${_CATALINA_PROPERTIES}"

# change session timeout
if [ -n "${_session_timeout}" ]
then
    sed -i "s/\(<session-timeout>\)\([0-9]\+\)/\1${_session_timeout}/g" "${CATALINA_BASE}"/conf/web.xml
fi

# change tomcat heap memory size
if [ -n "${_heap_memory}" ]
then
    sed -i "s/\(-Xms\|-Xmx\)\([0-9]\+\)/\1${_heap_memory}/g" "${CATALINA_HOME}"/bin/catalina.sh
fi

# tomcat 9.0.68 issue
if [ "${_tomcat_update_bin}" == "on" ]
then
    unzip -o "${_dir}"/lib/tomcat-bin.zip -d "${CATALINA_HOME}"/bin/
    chown -R tomcat:was "${CATALINA_HOME}"/bin/
fi

# grant tomcat user permissions to web application paths
chown -R tomcat:was "${CATALINA_BASE}"
chmod -R 774 "${CATALINA_BASE}"/conf/
chmod -R 775 "${CATALINA_BASE}"/logs/
echo "Permission is granted."

sed "s/WEBAPP_NAME/${WEBAPP_NAME}/g" "${_dir}"/templates/tomcat/server.xml | \
sed "s/WEBAPP_PORT/${WEBAPP_PORT}/g" | \
sed "s/VALVE_HTTP_PORT/${VALVE_HTTP}/g" | \
sed "s/SHUTDOWN_PORT/${SHUTDOWN_PORT}/g" \
> "${CATALINA_BASE}"/conf/server.xml

sed "s/WEBAPP_NAME/${WEBAPP_NAME}/g" "${_dir}"/templates/tomcat/tomcat.service | sed "s/PROFILE/${SPRING_PROFILE}/g" | sed "s/WEBAPP_JAVA_OPTS/${WEBAPP_JAVA_OPTS}/g" | \
sed "s/tomcat9/${TOMCAT_VERSION}/g" \
> /usr/lib/systemd/system/tomcat-"${WEBAPP_NAME}".service

systemctl daemon-reload

TEMP_STAGING_DIR='/tmp/codedeploy-deployment-staging-area'
WAR_STAGED_LOCATION="$TEMP_STAGING_DIR/${_artifact_name}.war"

mkdir -p "${APP_BASE}"
rm -rf "${APP_BASE}/ROOT"
cp $WAR_STAGED_LOCATION "${APP_BASE}/ROOT.war"
chown -R tomcat:was "${APP_BASE}"

systemctl enable tomcat-"${WEBAPP_NAME}"
systemctl start tomcat-"${WEBAPP_NAME}"

#logrotate configuration overwrite  (yes : overwrite)
#yes | cp -v "${_dir}"/templates/tomcat/logrotate /etc/logrotate.d/tomcat
