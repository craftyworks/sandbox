#!/bin/bash

# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0

_program="$0"
while [ -h "$_program" ] ; do
  ls=$(ls -ld "$_program")
  link=$(expr "$ls" : '.*-> \(.*\)$')
  if expr "$link" : '/.*' > /dev/null; then
    _program="$link"
  else
    _program=$(dirname "$_program")/"$link"
  fi
done
_dir=$(dirname "$_program")
_properties="$_dir"/properties/nginx/web.properties

function readProperty {
  grep "${1}" "${2}" | cut -d '=' -f2-
}

_web_server_port=$(readProperty 'web.server.port' "$_properties")
_target_url="http://127.0.0.1:${_web_server_port}/health-check.html"

for i in `seq 1 10`;
do
  HTTP_CODE=$(curl --write-out '%{http_code}' -v -o /dev/null -m 10 -q -s "${_target_url}")
  if [ "$HTTP_CODE" == "200" ]; then
    echo "Successfully pulled root page."
    exit 0;
  fi
  echo "Attempt to curl endpoint returned HTTP Code $HTTP_CODE. Backing off and retrying."
  sleep 10
done
echo "Server did not come up after expected time. Failing."
exit 1
