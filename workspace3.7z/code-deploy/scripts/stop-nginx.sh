#!/bin/bash

set -e

_program="$0"
while [ -h "$_program" ] ; do
  ls=$(ls -ld "$_program")
  link=$(expr "$ls" : '.*-> \(.*\)$')
  if expr "$link" : '/.*' > /dev/null; then
    _program="$link"
  else
    _program=$(dirname "$_program")/"$link"
  fi
done
_dir=$(dirname "$_program")
_properties="$_dir"/properties/nginx/web.properties

function readProperty {
  grep "${1}" "${2}" | cut -d '=' -f2-
}

_web_server_name=$(readProperty 'web.server.name' "$_properties")

if [ "$_web_server_name" != "artp1" ]
then
  echo "Don't stop Nginx"
  exit 0;
fi

_active=$(systemctl is-active nginx)

if [ "$_active" == "active" ]
then
  systemctl stop nginx
fi
