# CI/CD

## Nginx

### Config
    - Nginx Home : /data/web/nginx
    - Nginx Config : /data/web/nginx/conf/nginx.conf
    - Nginx Server Config : /data/web/nginx/conf/conf.d/${web.server.name}.conf

### Document Root
    - Path : /data/web-app/${web.server.root}

### Log
    - Log Home : /data/web/nginx/logs

### Stop & Start

    - Stop
        . systemctl stop nginx
    - Start
        . systemctl start nginx

## Tomcat

### Config
    - Tomcat Home : /data/was/tomcat9
    - Server Home : /data/was/tomcat9/${webapp.name}
    - Server Config : /data/was/tomcat9/${webapp.name}/conf/server.xml
    - Instance Root : /data/was-app/#{webapp.name}

### Log
    - Log Home : /data/was/tomcat9/${webapp.name}/logs
    - Console Log : /data/was/tomcat9/${webapp.name}/catalina.out
    - Access Log : /data/was/tomcat9/${webapp.name}/access_log.${yyyy-mm-dd}.log

### AttachFile
    - File Root : /data/File_Upload/#{webapp.name}

### Stop & Start

    - Stop 
        . systemctl stop tomcat-${webapp.name}
    - Start
        . systemctl start tomcat-${webapp.name}

### context.xml 암호화

JNDI DataSource 설정은 context.xml 파일에 설정합니다. 

DataSource 설정 정보는 context.properties 파일에 암호화 하여 등록합니다.

- context.xml
    ```xml
    <Resource
        name="jdbc/ctos"
        username="${db.username}"
        password="${db.password}"
        url="${db.url}"
    />
    ```

- context.properties
    ```
    db.username=ctosown
    db.password=CRYPT::wHfoWKCb215Pi47fGlFEXr4pr6rRMhZcrLRCG4geKdo=
    ```
- 평문 암호화
    - tomcat-context.jar 를 실행하여 평문을 암호화 합니다.
    - 암호화된 문자열을 context.properties 등록시에는 `CRYPT::` 접두어를 추가해야 합니다.
    ```java 
    java -jar tomcat-context.jar <암호화할 문자열>
    ```
