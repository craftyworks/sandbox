package com.sds.smtp;

import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.HtmlEmail;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@Setter
@ConfigurationProperties("app.smtp")
public class SmtpService {
    private String hostname;
    private int servicePort = 25;
    private boolean sslSupport;

    public String sendMail() throws EmailException {
        return sendMail(this.hostname, null);
    }

    public String sendMail(String hostname, String sendTo) throws EmailException {
        HtmlEmail email = new HtmlEmail();

        String hostName = LocalAddressUtil.getHostName();
        String ipAddress = LocalAddressUtil.getHostIp();

        // Create the email message
        email.setCharset("UTF-8");
        email.setHostName(hostname);
        email.setSmtpPort(servicePort);
        email.setSSLOnConnect(sslSupport);

        email.setSubject("[클라우드 CFT] 메일 발송 테스트 - " + hostName + " / " + ipAddress); // 제목
        email.setFrom("seokjin_yoon_sds@amorepacific.com", "윤석진"); // 보내는 사람
        // email.setFrom("support@emcast.com", "이니스쿨"); // 보내는 사람
        email.setHtmlMsg("<h1>Hello World</h1><br><h2>" + hostname + "</h2><br><h3>" + hostName + "</h3><br><h4>" + ipAddress + "</h4>"); // 본문

        // 수신인 지정
        if(sendTo != null) {
            email.addTo(sendTo);
        } else {
            email.addTo("seokjin_yoon_sds@amorepacific.com", "윤석진");
            email.addTo("myungsu.sung_sds@amorepacific.com", "성명수");
            email.addTo("youngdeok.jang_sds@amorepacific.com", "장영덕");

            email.addCc("seokjin_yoon@samsung.com", "윤석진");
            email.addCc("myungsu.sung@samsung.com", "성명수");
            email.addCc("youngdeok.jang@samsung.com", "장영덕");

            email.addCc("craftyworks@gmail.com", "윤석진");
            email.addCc("hydra0510@gmail.com", "성명수");
        }

        // send the email
        log.info("sending mail to smtp host : {}, port:{}, secure : {}", hostname, servicePort, sslSupport);
        String mailId = email.send();
        log.info("Send mail to SMTP : {}", mailId);
        return mailId;
    }
}
