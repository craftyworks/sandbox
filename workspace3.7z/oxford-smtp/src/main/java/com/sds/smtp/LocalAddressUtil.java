package com.sds.smtp;

import org.apache.http.conn.util.InetAddressUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Enumeration;

/**
 * 시스템의 IP Address 와 Host 명 제공을 위한 Utility Class.
 * <ul>
 * <li>Created by : 윤석진
 * <li>Created Date : 2017. 3. 12. 오후 11:47:19
 * </ul>
 *
 * @author 윤석진
 */
public class LocalAddressUtil {

    private static final Logger logger = LoggerFactory.getLogger(LocalAddressUtil.class); //NOPMD

    private final static String HOST_NAME;

    private final static String HOST_IP;

    static {
        InetAddress thisIp = null;
        try {
            thisIp = InetAddress.getLocalHost();
        } catch (Exception e) {
            logger.warn(e.getMessage(), e);
        }
        HOST_NAME = (thisIp != null) ? thisIp.getHostName() : "localhost";
        HOST_IP = getLocalIpAddress();
    }

    private static String getLocalIpAddress() {
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                NetworkInterface intf = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements(); ) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    // for getting IPV4 format
                    if (!inetAddress.isLoopbackAddress() && InetAddressUtils.isIPv4Address(inetAddress.getHostAddress())) {
                        return inetAddress.getHostAddress();
                    }
                }
            }
        } catch (Exception e) {
            logger.warn(e.getMessage(), e);
        }
        return "127.0.0.1";
    }

    public static String getHostName() {
        return HOST_NAME;
    }

    public static String getHostIp() {
        return HOST_IP;
    }
}
