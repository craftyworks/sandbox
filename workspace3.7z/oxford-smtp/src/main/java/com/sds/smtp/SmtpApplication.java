package com.sds.smtp;


import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.mail.EmailException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableAsync;

@EnableAsync
@SpringBootApplication(scanBasePackages = {"com.sds"})
@Slf4j
public class SmtpApplication implements CommandLineRunner {

    @Autowired
    SmtpService smtpService;

    public static void main(String[] args) {
        String springConfigLocations = "spring.config.location=classpath:config/application.yml";

        log.info("---------------------------");
        log.info("-   Start Your Engines!   -");
        log.info("---------------------------");

        ConfigurableApplicationContext context = new SpringApplicationBuilder(SmtpApplication.class)
            .properties(springConfigLocations)
            .run(args);
    }

    @Override
    public void run(String... args) {
        log.info("sending mail");

        try {
            if (args != null && args.length == 1) {
                smtpService.sendMail(args[0], null);
            } else if(args != null && args.length > 1) {
                for(int i = 1; i < args.length; i++) {
                    smtpService.sendMail(args[0], args[i]);
                }
            } else {
                smtpService.sendMail();
            }

        } catch (EmailException e) {
            log.error(e.getMessage(), e);
        }
    }
}
