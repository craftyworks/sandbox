# Usage

## spamsys.amorepacific.com 으로 발송

java -jar oxford-smtp.jar

## spam.amorepacific.com 으로 발송

java -jar oxford-smtp.jar spam.amorepacific.com

## 수신인 지정하여 발송

java -jar oxford-smtp.jar spam.amorepacific.com 수신자@email.com

java -jar oxford-smtp.jar spam.amorepacific.com 수신자1@email.com 수신자2@email.com
