
## 실행

```shell

java -Dspring.profiles.active=stage -jar oxford-dark.jar

```