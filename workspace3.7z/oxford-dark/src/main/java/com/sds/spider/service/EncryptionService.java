package com.sds.spider.service;

import com.sds.ctos.damo.app.DamoService;
import com.sds.spider.entity.DBColumn;
import com.sds.spider.mapper.SpiderMapper;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.cursor.Cursor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StopWatch;

import java.io.IOException;
import java.util.regex.Pattern;


@Service
@Setter
@Slf4j
@RequiredArgsConstructor
public class EncryptionService {

    private final DamoService damoService;

    private final SpiderMapper mapper;

    final static Pattern P_TARGET = Pattern.compile("^([^\\.]+)\\.([^\\.]+)\\.([^\\.]+)$");

    @Transactional
    public void doIt() {
        StopWatch stopWatch = new StopWatch("Encryption Service");

        try {
            stopWatch.start("encrypt");
            encryptColumn();
            stopWatch.stop();
        } catch (Exception e) {
            throw new RuntimeException("Encryption failed", e);
        }
        log.info("Encryption completed : {}", stopWatch.prettyPrint());
    }

    /**
     * DB 컬럼 암호화
     */
    private void encryptColumn() {
        long cnt = 0;
        log.info("SALE_ST.CARD_NO start");
        try (Cursor<DBColumn> list = mapper.selectList()) {
            for (DBColumn column : list) {
                cnt++;
                column.setValue(damoService.encrypt(column.getValue()));
                mapper.updateColumn(column);
            }
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        log.info("SALE_ST.CARD_NO end. total update count : {}", cnt);
        log.info("SALE_ST_T.CARD_NO start");
        cnt = 0;
        try (Cursor<DBColumn> list = mapper.selectList2()) {
            for (DBColumn column : list) {
                cnt++;
                column.setValue(damoService.encrypt(column.getValue()));
                mapper.updateColumn2(column);
            }
        } catch (IOException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
        log.info("SALE_ST_T.CARD_NO end. total update count : {}", cnt);
    }
}
