package com.sds.spider.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class DBColumn {
    private String rowid;
    private String value;
}
