package com.sds.spider.mapper;

import com.sds.spider.entity.DBColumn;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.cursor.Cursor;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface SpiderMapper {

    Cursor<DBColumn> selectList();

    void updateColumn(DBColumn column);

    Cursor<DBColumn> selectList2();

    void updateColumn2(DBColumn column);
}
