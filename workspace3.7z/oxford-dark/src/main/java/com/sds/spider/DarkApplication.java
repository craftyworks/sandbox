package com.sds.spider;

import com.sds.spider.service.EncryptionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@EnableAsync
@SpringBootApplication(scanBasePackages = {"com.sds"})
@EnableTransactionManagement
@RequiredArgsConstructor
@Slf4j
public class DarkApplication implements CommandLineRunner {

    private final EncryptionService encryptionService;
    private final Environment environment;

    public static void main(String[] args) {
        if (args == null || args.length < 1) {
            System.out.println("\nUSAGE : java -Dspring.profiles.active=stage -jar oxford-dark.jar <target application name> [decrypt]\n");
            System.out.println("Target Application List : \n");
            System.out.println(" ap-43-mucmp\n");
            System.exit(1);
        }

        String targetAppName = args[0];

        String springConfigLocations = "spring.config.location=classpath:config/application.yml,classpath:config/" + targetAppName + ".yml";

        log.info("---------------------------");
        log.info("-   Start Your Engines!   -");
        log.info("- {}", targetAppName);
        log.info("- {}", springConfigLocations);
        log.info("---------------------------");

        ConfigurableApplicationContext context = new SpringApplicationBuilder(DarkApplication.class)
            .properties(springConfigLocations)
            .run(args);
    }

    @Override
    public void run(String... args) {
        encryptionService.doIt();
    }
}
