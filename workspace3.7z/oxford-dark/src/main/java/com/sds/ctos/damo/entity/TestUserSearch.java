package com.sds.ctos.damo.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestUserSearch {
    private String reason;
}
