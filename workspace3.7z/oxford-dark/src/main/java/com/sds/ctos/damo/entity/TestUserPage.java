package com.sds.ctos.damo.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestUserPage extends TestUser {
    String encryptedUserName;
    String encryptedEmail;
    String companyNm;
    String deptNm;
}
