package com.sds.ctos.damo.core;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.web.client.RestTemplate;

@Configuration
@Slf4j
public class DamoConfig {

    @Bean
    @Profile({"local"})
    @ConfigurationProperties(prefix = "damo.api")
    public Damo damoAPI(RestTemplate restTemplate) {
        return new DamoAPI(restTemplate);
    }

    @Bean
    @Profile({"stage", "prod"})
    @ConfigurationProperties(prefix = "damo.v2-api")
    public Damo damoV2API() {
        return new DamoAPIV2();
    }
}
