package com.sds.ctos.damo.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestUserPageExcel extends TestUser {
    String userId;
    String userName;
    String email;
}
