package com.sds.ctos.damo.core;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DamoAPIRequest {
    @JsonIgnore
    final String url;

    @JsonProperty("inStr")
    final String input;

    public DamoAPIRequest(String url, String input) {
        this.url = url;
        this.input = input;
    }

    public String getUrl() {
        return url;
    }
}
