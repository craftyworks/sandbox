package com.sds.ctos.damo.core;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DamoAPIListRequest {
    @JsonIgnore
    final String url;

    public DamoAPIListRequest(String url) {
        this.url = url;
    }

    @JsonProperty("ScpDbAgentApiVo")
    List<InputString> list = new ArrayList<>();

    public void add(String input) {
        list.add(new InputString(input));
    }

    public String getUrl() {
        return this.url;
    }

    public List<InputString> getList() {
        return list;
    }

    public class InputString {
        @JsonProperty("inStr")
        final String input;

        public InputString(String input) {
            this.input = input;
        }
    }
}
