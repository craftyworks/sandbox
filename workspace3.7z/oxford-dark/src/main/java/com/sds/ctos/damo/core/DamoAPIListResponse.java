package com.sds.ctos.damo.core;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DamoAPIListResponse {
    @JsonProperty("ScpDbAgentApiVo")
    List<DamoAPIResponse> list;

    public List<DamoAPIResponse> getList() {
        return list;
    }

    public void setList(List<DamoAPIResponse> list) {
        this.list = list;
    }
}
