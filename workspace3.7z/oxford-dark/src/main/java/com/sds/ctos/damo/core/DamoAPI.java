package com.sds.ctos.damo.core;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
@RequiredArgsConstructor
@Slf4j
public class DamoAPI implements Damo {
    private static ObjectMapper objectMapper = new ObjectMapper();

    private final RestTemplate restTemplate;
    private String channelCode;
    private String systemCode;
    private String encryptUrl;
    private String decryptUrl;
    private String encryptListUrl;
    private String decryptListUrl;

    /**
     * 단건 암호화
     */
    @Override
    public String encrypt(String input) {
        DamoAPIRequest request = new DamoAPIRequest(encryptUrl, input);
        return execute(request).getOutput();
    }

    /**
     * 단건 복호화
     */
    @Override
    public String decrypt(String input) {
        DamoAPIRequest request = new DamoAPIRequest(decryptUrl, input);
        return execute(request).getOutput();
    }

    /**
     * 다건 암호화
     */
    @Override
    public List<String> encrypt(String... input) {
        DamoAPIListRequest request = new DamoAPIListRequest(encryptListUrl);
        for (String str : input) {
            request.add(str);
        }
        DamoAPIListResponse response = execute(request);
        if(response.getList().size() != request.getList().size()) {
            throw new RuntimeException("Encryption Failed 1");
        }
        return response.getList().stream().map(el -> el.getOutput()).collect(Collectors.toList());
    }

    /**
     * 다건 복호화
     */
    @Override
    public List<String> decrypt(String... input) {
        DamoAPIListRequest request = new DamoAPIListRequest(decryptListUrl);
        for (String str : input) {
            request.add(str);
        }
        DamoAPIListResponse response = execute(request);
        if(response.getList().size() != request.getList().size()) {
            throw new RuntimeException("Decryption Failed 1");
        }
        return response.getList().stream().map(el -> el.getOutput()).collect(Collectors.toList());
    }

    private DamoAPIResponse execute(DamoAPIRequest request) {
        DamoAPIResponse response = sendMessage(request.getUrl(), request, DamoAPIResponse.class);
        if (!response.isOk()) {
            log.error("ResultCode: {}, ResultMessage: {}", response.getResultCode(), response.getResultMessage());
        }
        return response;
    }

    private DamoAPIListResponse execute(DamoAPIListRequest request) {
        DamoAPIListResponse response = sendMessage(request.getUrl(), request, DamoAPIListResponse.class);
        for (DamoAPIResponse result : response.getList()) {
            if (!result.isOk()) {
                log.error("ResultCode: {}, ResultMessage: {}", result.getResultCode(), result.getResultMessage());
            }
        }
        return response;
    }


    private <T> T sendMessage(String url, Object message, Class<T> resultClass) {
        log.debug("URL: {}, {}", url, message);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
        headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
        headers.set("chCd", channelCode);
        headers.set("sysCd", systemCode);

        HttpEntity entity = new HttpEntity<>(message, headers);

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url);
        builder.queryParam("sysCd", systemCode);

        ResponseEntity<T> response = restTemplate.postForEntity(builder.toUriString(), entity, resultClass);

        if (HttpStatus.OK != response.getStatusCode()) {
            throw new DamoAPIException("D'Amo API Request Fail : " + response.getStatusCode());
        }

        try {
            log.debug("api response : {}, {}", response.getStatusCode(), objectMapper.writeValueAsString(response.getBody()));
        } catch (JsonProcessingException e) {
            log.error(e.getMessage(), e);
        }

        return response.getBody();
    }
}
