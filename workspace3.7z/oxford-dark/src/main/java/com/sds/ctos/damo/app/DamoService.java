package com.sds.ctos.damo.app;

import com.sds.ctos.damo.core.Damo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class DamoService {

    final Damo damoAPI;

    final ResourceLoader resourceLoader;

    /**
     * 생성자 주입
     */
    public DamoService(Damo damoAPI, ResourceLoader resourceLoader) {
        this.damoAPI = damoAPI;
        this.resourceLoader = resourceLoader;
    }

    /**
     * 단건 암호화
     */
    public String encrypt(String input) {
        return damoAPI.encrypt(input);
    }

    /**
     * 단건 복호화
     */
    public String decrypt(String input) {
        return damoAPI.decrypt(input);
    }

    /**
     * 다건 암호화
     */
    public List<String> encryptList(List<String> inputList) {
        return damoAPI.encrypt(inputList.stream().toArray(String[]::new));
    }

    /**
     * 다건 복호화
     */
    public List<String> decryptList(List<String> inputList) {
        return damoAPI.decrypt(inputList.stream().toArray(String[]::new));
    }

}
