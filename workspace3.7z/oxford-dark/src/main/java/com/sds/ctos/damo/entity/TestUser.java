package com.sds.ctos.damo.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TestUser {
    String userId;
    String userName;
    String email;
    String companyNm;
    String deptNm;
}
