package com.sds.ctos.damo.entity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EncryptRequestParam {
    private String encryptYn;
    private String inputString;
}
