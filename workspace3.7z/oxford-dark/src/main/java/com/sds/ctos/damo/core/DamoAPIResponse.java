package com.sds.ctos.damo.core;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DamoAPIResponse {
    public static final String SUCCESS_CODE = "ICITSVCOM000";

    @JsonProperty("inStr")
    String input;
    @JsonProperty("outStr")
    String output;
    @JsonProperty("rsltCd")
    String resultCode;
    @JsonProperty("rsltMsg")
    String resultMessage;

    public String getInput() {
        return input;
    }

    public void setInput(String input) {
        this.input = input;
    }

    public String getOutput() {
        return output;
    }

    public void setOutput(String output) {
        this.output = output;
    }

    public String getResultCode() {
        return resultCode;
    }

    public void setResultCode(String resultCode) {
        this.resultCode = resultCode;
    }

    public String getResultMessage() {
        return resultMessage;
    }

    public void setResultMessage(String resultMessage) {
        this.resultMessage = resultMessage;
    }

    public boolean isOk() {
        return SUCCESS_CODE.equals(resultCode);
    }
}
