package com.sds.ctos.damo.core;

import java.util.List;

public interface Damo {
    /**
     * 단건 암호화
     */
    String encrypt(String input);

    /**
     * 단건 복호화
     */
    String decrypt(String input);

    /**
     * 다건 암호화
     */
    List<String> encrypt(String... input);

    /**
     * 다건 복호화
     */
    List<String> decrypt(String... input);
}
