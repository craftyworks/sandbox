package com.sds.ctos.damo.core;

import com.penta.scpdb.ScpDbAgent;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@RequiredArgsConstructor
@Slf4j
public class DamoAPIV2 implements Damo {
    private String iniFilePath;
    private String encryptionKey;
    private String decryptionKey;

    private ScpDbAgent agent = new ScpDbAgent();

    /**
     * 단건 암호화
     */
    @Override
    public String encrypt(String input) {
        return agent.ScpEncStr(iniFilePath, encryptionKey, input);
    }

    /**
     * 단건 복호화
     */
    @Override
    public String decrypt(String input) {
        return agent.ScpDecStr(iniFilePath, decryptionKey, input);
    }

    /**
     * 다건 암호화
     */
    @Override
    public List<String> encrypt(String... input) {
        List<String> result = new ArrayList<>();
        for (String str : input) {
            result.add(encrypt(str));
        }
        return result;
    }

    /**
     * 다건 복호화
     */
    @Override
    public List<String> decrypt(String... input) {
        List<String> result = new ArrayList<>();
        for (String str : input) {
            result.add(decrypt(str));
        }
        return result;
    }
}
