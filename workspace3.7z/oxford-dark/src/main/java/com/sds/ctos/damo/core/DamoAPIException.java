package com.sds.ctos.damo.core;



public class DamoAPIException extends RuntimeException {

    public DamoAPIException(String message) {
        super(message);
    }
    public DamoAPIException(String message, Throwable cause) {
        super(message, cause);
    }

}
