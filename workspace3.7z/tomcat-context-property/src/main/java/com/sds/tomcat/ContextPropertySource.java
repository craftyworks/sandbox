package com.sds.tomcat;

import org.apache.catalina.Globals;
import org.apache.tomcat.util.IntrospectionUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;

public class ContextPropertySource implements IntrospectionUtils.PropertySource {
    private static final Log log = LogFactory.getLog(ContextPropertySource.class);
    private static final String CRYPT_PREFIX = "CRYPT::";
    private static final String PROPERTY_FILE_RELATIVE_PATH = "/conf/context.properties";
    private Properties properties;

    public ContextPropertySource() {
        this.properties = null;
        log.info("----------------------------------");
        log.info("- Tomcat Context Property Source -");
        log.info("----------------------------------");

        String catalinaHome = System.getProperty(Globals.CATALINA_HOME_PROP);
        String catalinaBase = System.getProperty(Globals.CATALINA_BASE_PROP);
        String catalina = null;

        if (new File(catalinaBase + PROPERTY_FILE_RELATIVE_PATH).exists()) {
            catalina = catalinaBase;
            log.info("context.properties found in catalina.base [" + catalina + "]");
        } else if (new File(catalinaHome + PROPERTY_FILE_RELATIVE_PATH).exists()) {
            catalina = catalinaHome;
            log.info("context.properties found in catalina.home [" + catalina + "]");
        } else {
            catalina = catalinaBase;
            log.info("context.properties not found, using catalina.base [" + catalina + "]");
        }

        String propertiesPath = catalina + PROPERTY_FILE_RELATIVE_PATH;
        this.init(propertiesPath);
    }

    private void init(final String propertiesPath) {
        this.properties = new Properties();

        try (InputStream input = new FileInputStream(propertiesPath)) {
            properties.load(input);
        } catch (IOException ex) {
            log.error(ex.getMessage(), ex);
        }
    }

    @Override
    public String getProperty(final String name) {
        String result = null;
        if(this.properties.containsKey(name)) {
            result = this.properties.getProperty(name);
            if (result != null && result.startsWith(CRYPT_PREFIX)) {
                try {
                    return EncryptionUtil.decrypt(result.substring(CRYPT_PREFIX.length()));
                } catch (Exception ex) {
                    log.error(ex.getMessage(), ex);
                }
            }
        } else if(System.getProperties().containsKey(name)) {
            result = System.getProperty(name);
        } else if(System.getenv().containsKey(name)) {
            result = System.getenv(name);
        }
        log.info("context property key[" + name + "] value[" + result + "]");
        return result;
    }
}
