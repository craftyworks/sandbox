package com.sds.tomcat;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.Key;
import java.util.Base64;

public class EncryptionUtil {
    private static final String ALGORITHM = "AES/CBC/PKCS5Padding";
    private static final String KEY = "tdVptDTuqbFXXWZFPqlxcLaSoXbamjgs"; // 32 Byte Key
    private static final String IV;
    private static final Key KEYSPEC;

    static {
        IV = KEY.substring(0, 16);
        KEYSPEC = new SecretKeySpec(KEY.getBytes(), "AES");
    }

    // 암호화
    public static String encrypt(String text) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, KEYSPEC, new IvParameterSpec(IV.getBytes()));

        byte[] encrypted = cipher.doFinal(text.getBytes("UTF-8"));
        return Base64.getEncoder().encodeToString(encrypted);
    }

    // 복호화
    static String decrypt(String cipherText) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, KEYSPEC, new IvParameterSpec(IV.getBytes()));

        byte[] decodedBytes = Base64.getDecoder().decode(cipherText);
        byte[] decrypted = cipher.doFinal(decodedBytes);
        return new String(decrypted, "UTF-8");
    }

    public static void main(String[] args) throws Exception {
        String d = "f8kMB710$28";
        System.out.println("###:" + encrypt(d));
        String s = "al2t4QRHvwAJRRZzLpHTqw==";
        System.out.println("###:" + decrypt(s));
        String s2 = "6elIWnnuC3QdWLL5M2nW6Q==";
        System.out.println("###:" + decrypt(s2));

        if (args == null || args.length != 1) {
            System.out.println("\nUSAGE : java -jar tomcat-context.jar <plain text>\n");
            System.exit(1);
        }

        System.out.println("target:" + args[0]);
        System.out.println(encrypt(args[0]));
    }
}
